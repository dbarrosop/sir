DATABASE = '/mnt/drive/sir/output/pmacct.db'
BGP_FOLDER = '/mnt/drive/sir/output/bgp/'
DEBUG = False
SECRET_KEY = 'development key'
BIND_IP = '127.0.0.1'
PORT = 5000
